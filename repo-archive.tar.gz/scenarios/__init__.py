"""Scenario detection package."""
from .engine import detect_scenarios
__all__ = ["detect_scenarios"]
