testthat::test_that("basic math works", {
  testthat::expect_equal(1 + 1, 2)
})
