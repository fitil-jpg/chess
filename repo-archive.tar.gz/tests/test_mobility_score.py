import chess
from core.evaluator import Evaluator

def test_mobility_score_recorded():
    board = chess.Board()
    evaluator = Evaluator(board)
    white, black = evaluator.mobility(board)
    metrics = evaluator.compute_final_metrics()
    assert metrics['white_mobility'] == white
    assert metrics['black_mobility'] == black
    assert metrics['mobility_score'] == white - black


def test_mobility_handles_iterator_without_count():
    class DummyBoard(chess.Board):
        @property  # type: ignore[override]
        def legal_moves(self):
            return iter(super().legal_moves)

    board = DummyBoard()
    evaluator = Evaluator(board)
    white, black = evaluator.mobility(board)
    assert white >= 0 and black >= 0


def test_per_piece_mobility_flags():
    board = chess.Board()
    board.clear()
    board.set_piece_at(chess.A1, chess.Piece(chess.KING, chess.WHITE))
    board.set_piece_at(chess.A2, chess.Piece(chess.PAWN, chess.WHITE))
    board.set_piece_at(chess.B3, chess.Piece(chess.PAWN, chess.BLACK))  # attacks A2
    evaluator = Evaluator(board)
    evaluator.mobility(board)
    pawn_stats = evaluator.mobility_stats['white']['pieces'][chess.A2]
    assert pawn_stats['mobility'] == 2
    assert pawn_stats['blocked'] is False
    assert pawn_stats['capturable'] is True


def test_diagonal_pawn_attack_sets_capturable():
    """A pawn attacked by an enemy pawn diagonally is marked capturable."""
    board = chess.Board()
    board.clear()
    board.set_piece_at(chess.A1, chess.Piece(chess.KING, chess.WHITE))
    board.set_piece_at(chess.A2, chess.Piece(chess.PAWN, chess.WHITE))
    board.set_piece_at(chess.B3, chess.Piece(chess.PAWN, chess.BLACK))  # attacks A2
    board.turn = chess.BLACK  # ensure turn doesn't hide pawn attacks
    evaluator = Evaluator(board)
    evaluator.mobility(board)
    pawn_stats = evaluator.mobility_stats['white']['pieces'][chess.A2]
    assert pawn_stats['capturable'] is True


def test_king_status_checkmate_and_stalemate():
    # Checkmate scenario: black king on h8 is in check with no escape squares
    mate = chess.Board("7k/6Q1/6K1/8/8/8/8/8 w - - 0 1")
    evaluator = Evaluator(mate)
    evaluator.mobility(mate)
    ksq = mate.king(chess.BLACK)
    status = evaluator.mobility_stats['black']['pieces'][ksq]['status']
    assert status == 'checkmated'

    # Stalemate scenario: black king has no legal moves but is not in check
    stale = chess.Board("7k/5Q2/6K1/8/8/8/8/8 w - - 0 1")
    evaluator = Evaluator(stale)
    evaluator.mobility(stale)
    ksq = stale.king(chess.BLACK)
    status = evaluator.mobility_stats['black']['pieces'][ksq]['status']
    assert status == 'stalemated'


def test_king_status_forced_checkmate_position():
    """Ensure a forced checkmate is recognised over stalemate."""
    # Fool's Mate checkmate: white king is checkmated on move 2...Qh4#
    board = chess.Board("rnb1kbnr/pppp1ppp/8/4p3/4P2q/5P2/PPPP2PP/RNBQKBNR w KQkq - 0 3")
    evaluator = Evaluator(board)
    evaluator.mobility(board)
    ksq = board.king(chess.WHITE)
    status = evaluator.mobility_stats['white']['pieces'][ksq]['status']
    assert status == 'checkmated'
