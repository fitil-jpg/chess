"""Convenience wrappers for FEN parsing, heatmap generation and metrics.

This module exposes a tiny API that other projects can use to interact
with the chess analysis tools provided by this repository.
"""

from __future__ import annotations

import json
import subprocess
import logging
logger = logging.getLogger(__name__)

from pathlib import Path
from typing import Iterable, List, Dict, Any

import chess

from fen_handler import fen_to_board_state
from analysis.loader import export_fen_table
from metrics import MetricsManager


def parse_fen(fen: str) -> List[List[str | None]]:
    """Return a board representation for *fen*.

    The board is represented as an 8×8 list where each entry is a piece
    name or ``None`` for empty squares.
    """

    return fen_to_board_state(fen)


def generate_heatmaps(
    fens: Iterable[str],
    out_dir: str | Path | None = None,
    pattern_set: str = "default",
    use_wolfram: bool = False,
) -> Dict[str, Dict[str, List[List[int]]]]:
    """Generate heatmaps for *fens* and return them as dictionaries.

    This function serialises ``fens`` into a CSV file and invokes either the
    R or Wolfram heatmap scripts.  When ``use_wolfram`` is ``False`` (the
    default) ``analysis/heatmaps/generate_heatmaps.R`` is executed via
    ``Rscript``.  When ``True`` the Wolfram Language implementation
    ``analysis/heatmaps/generate_heatmaps.wl`` is run via ``wolframscript``.
    The resulting JSON heatmaps are loaded from ``analysis/heatmaps/<pattern_set>``
    (or ``out_dir/<pattern_set>`` when ``out_dir`` is provided) and returned as
    ``{pattern_set: {fen_id: matrix}}`` with each matrix being an 8×8 grid of
    integers.
    """

    base_path = Path(out_dir) if out_dir is not None else Path("analysis/heatmaps")
    out_path = base_path / pattern_set
    out_path.mkdir(parents=True, exist_ok=True)
    csv_path = out_path / "fens.csv"
    export_fen_table(fens, csv_path=str(csv_path))

    if use_wolfram:
        script = Path("analysis/heatmaps/generate_heatmaps.wl")
        cmd = ["wolframscript", "-file", str(script), str(csv_path)]
        missing = "wolframscript not found; install Wolfram Engine to generate heatmaps"
        fail_msg = "wolframscript failed"
    else:
        script = Path("analysis/heatmaps/generate_heatmaps.R")
        cmd = ["Rscript", str(script), str(csv_path)]
        missing = "Rscript not found; install R to generate heatmaps"
        fail_msg = "Rscript failed"

    try:
        subprocess.run(cmd, check=True)
    except FileNotFoundError as exc:
        raise RuntimeError(missing) from exc
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(f"{fail_msg}: {exc}") from exc

    heatmaps: Dict[str, List[List[int]]] = {}
    heatmap_files = list(out_path.glob("heatmap_*.json"))
    if not heatmap_files:
        raise RuntimeError(f"No heatmap files generated in {out_path}")
    for json_file in heatmap_files:
        with json_file.open("r", encoding="utf-8") as fh:
            heatmaps[json_file.stem.replace("heatmap_", "")] = json.load(fh)
    return {pattern_set: heatmaps}


def compute_metrics(fen: str) -> Dict[str, Dict[str, Any]]:
    """Compute short- and long-term metrics for *fen*.

    The returned dictionary contains two keys, ``short_term`` and
    ``long_term``, each mapping metric names to integer scores.
    """

    board = chess.Board(fen)
    mgr = MetricsManager(board)
    mgr.update_all_metrics()
    return mgr.get_metrics()


__all__ = ["parse_fen", "generate_heatmaps", "compute_metrics"]
